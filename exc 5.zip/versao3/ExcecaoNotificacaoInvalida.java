public class ExcecaoNotificacaoInvalida extends Exception {
    public ExcecaoNotificacaoInvalida(String mensagem) {
        super(mensagem);
    }
} 