import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Escolha o tipo de notificação:");
            System.out.println("1: Email");
            System.out.println("2: SMS");
            System.out.println("3: Push");

            String tipo = scanner.nextLine();
            
            Notificacao notificacao = FabricaNotificacao.criarNotificacao(tipo);
            
            System.out.println("Digite a mensagem:");
            String mensagem = scanner.nextLine();
            notificacao.enviar(mensagem);
            
        } catch (ExcecaoNotificacaoInvalida e) {
            System.out.println("Erro: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
} 