public class FabricaNotificacao {
    public static Notificacao criarNotificacao(String tipo) throws ExcecaoNotificacaoInvalida {
        return switch (tipo) {
            case "1" -> new NotificacaoEmail();
            case "2" -> new NotificacaoSms();
            case "3" -> new NotificacaoPush();
            default -> throw new ExcecaoNotificacaoInvalida("Tipo de notificação inválido: " + tipo);
        };
    }
} 